package fi.fmi.avi.converter.iwxxm.conf;

import fi.fmi.avi.converter.ConversionSpecification;
import fi.fmi.avi.model.GenericAviationWeatherMessage;
import fi.fmi.avi.model.bulletin.GenericMeteorologicalBulletin;
import fi.fmi.avi.model.metar.METAR;
import fi.fmi.avi.model.metar.SPECI;
import fi.fmi.avi.model.sigmet.AIRMET;
import fi.fmi.avi.model.sigmet.SIGMET;
import fi.fmi.avi.model.swx.amd79.SpaceWeatherAdvisoryAmd79;
import fi.fmi.avi.model.swx.amd79.SpaceWeatherAmd79Bulletin;
import fi.fmi.avi.model.swx.amd82.SpaceWeatherAdvisoryAmd82;
import fi.fmi.avi.model.swx.amd82.SpaceWeatherAmd82Bulletin;
import fi.fmi.avi.model.taf.TAF;
import fi.fmi.avi.model.taf.TAFBulletin;
import icao.iwxxm21.TAFType;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.Import;
import org.w3c.dom.Document;

/**
 * Created by rinne on 10/02/17.
 */
@Configuration
@Import({ IWXXMTAFConverter.class, IWXXMMETARSPECIConverter.class, IWXXMSIGMETAIRMETConverter.class, IWXXMSpaceWeatherConverter.class,
        IWXXMGenericAviationWeatherMessageConverter.class })
public class IWXXMConverter {

    // *******************
    //    TAF
    // *******************

    /**
     * Pre-configured spec for {@link TAF} to IWXXM 2.1 XML format TAF document String.
     */
    public static final ConversionSpecification<TAF, String> TAF_POJO_TO_IWXXM21_STRING = new ConversionSpecification<>(TAF.class, String.class, null,
            "TAF, XML/IWXXM 2.1");

    /**
     * Pre-configured spec for {@link TAF} to IWXXM 3.0 XML format TAF document String.
     * This spec ignores the patch version number, generally referring to the latest supported patch version.
     */
    public static final ConversionSpecification<TAF, String> TAF_POJO_TO_IWXXM30_STRING = new ConversionSpecification<>(TAF.class, String.class, null,
            "TAF, XML/IWXXM 3.0");

    /**
     * Pre-configured spec for {@link TAF} to IWXXM 2.1 XML format TAF document DOM Node.
     */
    public static final ConversionSpecification<TAF, Document> TAF_POJO_TO_IWXXM21_DOM = new ConversionSpecification<>(TAF.class, Document.class, null,
            "TAF, XML/IWXXM 2.1");

    /**
     * Pre-configured spec for {@link TAF} to IWXXM 3.0 XML format TAF document DOM Node.
     * This spec ignores the patch version number, generally referring to the latest supported patch version.
     */
    public static final ConversionSpecification<TAF, Document> TAF_POJO_TO_IWXXM30_DOM = new ConversionSpecification<>(TAF.class, Document.class, null,
            "TAF, XML/IWXXM 3.0");

    /**
     * Pre-configured spec for {@link TAF} to IWXXM 2.1 XML format TAFType JAXB class.
     */
    public static final ConversionSpecification<TAF, TAFType> TAF_POJO_TO_IWXXM21_JAXB = new ConversionSpecification<>(TAF.class, TAFType.class, null, null);

    /**
     * Pre-configured spec for IWXXM 2.1 XML format TAF document String to {@link TAF}.
     */
    public static final ConversionSpecification<String, TAF> IWXXM21_STRING_TO_TAF_POJO = new ConversionSpecification<>(String.class, TAF.class,
            "TAF, XML/IWXXM 2.1", null);

    /**
     * Pre-configured spec for IWXXM 3.0 XML format TAF document String to {@link TAF}.
     */
    public static final ConversionSpecification<String, TAF> IWXXM30_STRING_TO_TAF_POJO = new ConversionSpecification<>(String.class, TAF.class,
            "TAF, XML/IWXXM 3.0", null);

    /**
     * Pre-configured spec for IWXXM 2.1 XML format TAF document DOM Node to {@link TAF}.
     */
    public static final ConversionSpecification<Document, TAF> IWXXM21_DOM_TO_TAF_POJO = new ConversionSpecification<>(Document.class, TAF.class,
            "TAF, XML/IWXXM 2.1", null);

    /**
     * Pre-configured spec for IWXXM 3.0 XML format TAF document DOM Node to {@link TAF}.
     */
    public static final ConversionSpecification<Document, TAF> IWXXM30_DOM_TO_TAF_POJO = new ConversionSpecification<>(Document.class, TAF.class,
            "TAF, XML/IWXXM 3.0", null);

    /**
     * Pre-configured spec for {@link TAFBulletin} to WMO COLLECT 1.2 XML String containing IWXXM 2.1 TAFs.
     */
    public static final ConversionSpecification<TAFBulletin, String> TAF_BULLETIN_POJO_TO_WMO_COLLECT_STRING = new ConversionSpecification<>(TAFBulletin.class,
            String.class, null, "XML/WMO COLLECT 1.2 + IWXXM 2.1 TAF");

    /**
     * Pre-configured spec for {@link TAFBulletin} to WMO COLLECT 1.2 XML String containing IWXXM 3.0 TAFs.
     */
    public static final ConversionSpecification<TAFBulletin, String> TAF_BULLETIN_POJO_TO_WMO_COLLECT_IWXXM30_STRING = new ConversionSpecification<>(
            TAFBulletin.class, String.class, null, "XML/WMO COLLECT 1.2 + IWXXM 3.0 TAF");

    /**
     * Pre-configured spec for {@link TAFBulletin} to WMO COLLECT 1.2 XML DOM document containing IWXXM 2.1 TAFs.
     */
    public static final ConversionSpecification<TAFBulletin, Document> TAF_BULLETIN_POJO_TO_WMO_COLLECT_DOM = new ConversionSpecification<>(TAFBulletin.class,
            Document.class, null, "XML/WMO COLLECT 1.2 + IWXXM 2.1 TAF");

    /**
     * Pre-configured spec for {@link TAFBulletin} to WMO COLLECT 1.2 XML DOM document containing IWXXM 3.0 TAFs.
     */
    public static final ConversionSpecification<TAFBulletin, Document> TAF_BULLETIN_POJO_TO_WMO_COLLECT_IWXXM30_DOM = new ConversionSpecification<>(
            TAFBulletin.class, Document.class, null, "XML/WMO COLLECT 1.2 + IWXXM 3.0 TAF");

    /**
     * Pre-configured spec for WMO COLLECT 1.2 XML String containing IWXXM 2.1 TAFs to {@link TAFBulletin}.
     */
    public static final ConversionSpecification<String, TAFBulletin> WMO_COLLECT_STRING_TO_TAF_BULLETIN_POJO = new ConversionSpecification<>(String.class,
            TAFBulletin.class, "XML/WMO COLLECT 1.2 + IWXXM 2.1 TAF", null);

    /**
     * Pre-configured spec for WMO COLLECT 1.2 XML String containing IWXXM 3.0 TAFs to {@link TAFBulletin}.
     */
    public static final ConversionSpecification<String, TAFBulletin> WMO_COLLECT_IWXXM30_STRING_TO_TAF_BULLETIN_POJO = new ConversionSpecification<>(
            String.class, TAFBulletin.class, "XML/WMO COLLECT 1.2 + IWXXM 3.0 TAF", null);

    /**
     * Pre-configured spec for WMO COLLECT 1.2 XML DOM document containing IWXXM 2.1 TAFs to {@link TAFBulletin}.
     */
    public static final ConversionSpecification<Document, TAFBulletin> WMO_COLLECT_DOM_TO_TAF_BULLETIN_POJO = new ConversionSpecification<>(Document.class,
            TAFBulletin.class, "XML/WMO COLLECT 1.2 + IWXXM 2.1 TAF", null);

    /**
     * Pre-configured spec for WMO COLLECT 1.2 XML DOM document containing IWXXM 3.0 TAFs to {@link TAFBulletin}.
     */
    public static final ConversionSpecification<Document, TAFBulletin> WMO_COLLECT_IWXXM30_DOM_TO_TAF_BULLETIN_POJO = new ConversionSpecification<>(
            Document.class, TAFBulletin.class, "XML/WMO COLLECT 1.2 + IWXXM 3.0 TAF", null);

    // *******************
    //  METAR & SPECI
    // *******************

    /**
     * Pre-configured spec for IWXXM 2.1 XML format METAR document String to {@link METAR}.
     */
    public static final ConversionSpecification<String, METAR> IWXXM21_STRING_TO_METAR_POJO = new ConversionSpecification<>(String.class, METAR.class,
            "METAR, XML/IWXXM 2.1", null);

    /**
     * Pre-configured spec for IWXXM 2.1 XML format METAR document DOM Node to {@link METAR}.
     */
    public static final ConversionSpecification<Document, METAR> IWXXM21_DOM_TO_METAR_POJO = new ConversionSpecification<>(Document.class, METAR.class,
            "METAR, XML/IWXXM 2.1", null);

    /**
     * Pre-configured spec for IWXXM 2.1 XML format SPECI document String to {@link SPECI}.
     */
    public static final ConversionSpecification<String, SPECI> IWXXM21_STRING_TO_SPECI_POJO = new ConversionSpecification<>(String.class, SPECI.class,
            "SPECI, XML/IWXXM 2.1", null);

    /**
     * Pre-configured spec for IWXXM 2.1 XML format SPECI document DOM Node to {@link SPECI}.
     */
    public static final ConversionSpecification<Document, SPECI> IWXXM21_DOM_TO_SPECI_POJO = new ConversionSpecification<>(Document.class, SPECI.class,
            "SPECI, XML/IWXXM 2.1", null);

    // *******************
    //  SIGMET & AIRMET
    // *******************
    /**
     * Pre-configured spec for {@link SIGMET} to IWXXM 2.1 XML format SIGMET document String.
     */
    public static final ConversionSpecification<SIGMET, String> SIGMET_POJO_TO_IWXXM21_STRING = new ConversionSpecification<>(SIGMET.class, String.class, null,
            "SIGMET, XML/IWXXM 2.1");

    /**
     * Pre-configured spec for {@link SIGMET} to IWXXM 2.1 XML format SIGMET document DOM Node.
     */
    public static final ConversionSpecification<SIGMET, Document> SIGMET_POJO_TO_IWXXM21_DOM = new ConversionSpecification<>(SIGMET.class, Document.class, null,
            "SIGMET, XML/IWXXM 2.1");

    /**
     * Pre-configured spec for {@link SIGMET} to IWXXM 3.0 XML format SIGMET document String.
     */
    public static final ConversionSpecification<SIGMET, String> SIGMET_POJO_TO_IWXXM30_STRING = new ConversionSpecification<>(SIGMET.class, String.class, null,
            "SIGMET, XML/IWXXM 3.0");

    /**
     * Pre-configured spec for {@link SIGMET} to IWXXM 3.0 XML format SIGMET document DOM Node.
     */
    public static final ConversionSpecification<SIGMET, Document> SIGMET_POJO_TO_IWXXM30_DOM = new ConversionSpecification<>(SIGMET.class, Document.class, null,
            "SIGMET, XML/IWXXM 3.0");

    /**
     * Pre-configured spec for {@link SIGMET} to IWXXM 2023-1 XML format SIGMET document String.
     */
    public static final ConversionSpecification<SIGMET, String> SIGMET_POJO_TO_IWXXM2023_1_STRING = new ConversionSpecification<>(SIGMET.class, String.class, null,
            "SIGMET, XML/IWXXM 2023-1");

    /**
     * Pre-configured spec for {@link SIGMET} to IWXXM 2023-1 XML format SIGMET document DOM Node.
     */
    public static final ConversionSpecification<SIGMET, Document> SIGMET_POJO_TO_IWXXM2023_1_DOM = new ConversionSpecification<>(SIGMET.class, Document.class, null,
            "SIGMET, XML/IWXXM 2023-1");

    /**
     * Pre-configured spec for {@link AIRMET} to IWXXM 2.1 XML format AIRMET document String.
    */
    public static final ConversionSpecification<AIRMET, String> AIRMET_POJO_TO_IWXXM21_STRING = new ConversionSpecification<>(AIRMET.class, String.class, null,
            "AIRMET, XML/IWXXM 2.1");

    /**
    * Pre-configured spec for {@link AIRMET} to IWXXM 2.1 XML format AIRMET document DOM Node.
    */
    public static final ConversionSpecification<AIRMET, Document> AIRMET_POJO_TO_IWXXM21_DOM = new ConversionSpecification<>(AIRMET.class, Document.class, null,
            "AIRMET, XML/IWXXM 2.1");

    /**
     * Pre-configured spec for {@link AIRMET} to IWXXM 3.0 XML format AIRMET document String.
    */
    public static final ConversionSpecification<AIRMET, String> AIRMET_POJO_TO_IWXXM30_STRING = new ConversionSpecification<>(AIRMET.class, String.class, null,
            "AIRMET, XML/IWXXM 3.0");

    /**
     * Pre-configured spec for {@link AIRMET} to IWXXM 3.0 XML format AIRMET document DOM Node.
    */
    public static final ConversionSpecification<AIRMET, Document> AIRMET_POJO_TO_IWXXM30_DOM = new ConversionSpecification<>(AIRMET.class, Document.class, null,
            "AIRMET, XML/IWXXM 3.0");

    /**
     * Pre-configured spec for {@link AIRMET} to IWXXM 2023-1 XML format AIRMET document String.
     */
    public static final ConversionSpecification<AIRMET, String> AIRMET_POJO_TO_IWXXM2023_1_STRING = new ConversionSpecification<>(AIRMET.class, String.class, null,
            "AIRMET, XML/IWXXM 2023-1");

    /**
     * Pre-configured spec for {@link AIRMET} to IWXXM 2023-1 XML format AIRMET document DOM Node.
     */
    public static final ConversionSpecification<AIRMET, Document> AIRMET_POJO_TO_IWXXM2023_1_DOM = new ConversionSpecification<>(AIRMET.class, Document.class, null,
            "AIRMET, XML/IWXXM 2023-1");

    // *******************
    //  Space weather
    // *******************
    /**
     * Pre-configured spec for IWXXM 3.0 XML format Space Weather Advisory document String to {@link SpaceWeatherAdvisoryAmd79}.
     */
    public static final ConversionSpecification<String, SpaceWeatherAdvisoryAmd79> IWXXM30_STRING_TO_SPACE_WEATHER_POJO = new ConversionSpecification<>(String.class,
            SpaceWeatherAdvisoryAmd79.class, "SWX, XML/IWXXM 3.0", null);

    /**
     * Pre-configured spec for IWXXM 3.0 XML format Space Weather Advisory document DOM node to {@link SpaceWeatherAdvisoryAmd79}.
     */
    public static final ConversionSpecification<Document, SpaceWeatherAdvisoryAmd79> IWXXM30_DOM_TO_SPACE_WEATHER_POJO = new ConversionSpecification<>(
            Document.class, SpaceWeatherAdvisoryAmd79.class, "SWX, XML/IWXXM 3.0", null);

    /**
     * Pre-configured spec for {@link SpaceWeatherAdvisoryAmd79} to IWXXM 3.0 XML format SWX document String.
     */
    public static final ConversionSpecification<SpaceWeatherAdvisoryAmd79, String> SPACE_WEATHER_POJO_TO_IWXXM30_STRING = new ConversionSpecification<>(
            SpaceWeatherAdvisoryAmd79.class, String.class, null, "SWX, XML/IWXXM 3.0");

    /**
     * Pre-configured spec for {@link SpaceWeatherAdvisoryAmd79} to IWXXM 3.0 XML format SWX document DOM node.
     */
    public static final ConversionSpecification<SpaceWeatherAdvisoryAmd79, Document> SPACE_WEATHER_POJO_TO_IWXXM30_DOM = new ConversionSpecification<>(
            SpaceWeatherAdvisoryAmd79.class, Document.class, null, "SWX, XML/IWXXM 3.0");

    /**
     * Pre-configured spec for {@link SpaceWeatherAmd79Bulletin} to WMO COLLECT 1.2 XML String containing IWXXM 3.0 SpaceWeatherAdvisories.
     */
    public static final ConversionSpecification<SpaceWeatherAmd79Bulletin, String> SWX_30_BULLETIN_POJO_TO_WMO_COLLECT_STRING = new ConversionSpecification<>(
            SpaceWeatherAmd79Bulletin.class, String.class, null, "XML/WMO COLLECT 1.2 + IWXXM 3.0 SWX");

    /**
     * Pre-configured spec for {@link SpaceWeatherAmd79Bulletin} to WMO COLLECT 1.2 XML DOM document containing IWXXM 3.0 SpaceWeatherAdvisories.
     */
    public static final ConversionSpecification<SpaceWeatherAmd79Bulletin, Document> SWX_30_BULLETIN_POJO_TO_WMO_COLLECT_DOM = new ConversionSpecification<>(
            SpaceWeatherAmd79Bulletin.class, Document.class, null, "XML/WMO COLLECT 1.2 + IWXXM 3.0 SWX");

    /**
     * Pre-configured spec for WMO COLLECT 1.2 XML String containing IWXXM 3.0 SpaceWeatherAdvisories to {@link SpaceWeatherAmd79Bulletin}.
     */
    public static final ConversionSpecification<String, SpaceWeatherAmd79Bulletin> WMO_COLLECT_STRING_TO_SWX_30_BULLETIN_POJO = new ConversionSpecification<>(
            String.class, SpaceWeatherAmd79Bulletin.class, "XML/WMO COLLECT 1.2 + IWXXM 3.0 SWX", null);

    /**
     * Pre-configured spec for WMO COLLECT 1.2 XML DOM document containing IWXXM 3.0 SpaceWeatherAdvisories to {@link SpaceWeatherAmd79Bulletin}.
     */
    public static final ConversionSpecification<Document, SpaceWeatherAmd79Bulletin> WMO_COLLECT_DOM_TO_SWX_30_BULLETIN_POJO = new ConversionSpecification<>(
            Document.class, SpaceWeatherAmd79Bulletin.class, "XML/WMO COLLECT 1.2 + IWXXM 3.0 SWX", null);

    /**
     * Pre-configured spec for {@link SpaceWeatherAdvisoryAmd82} to IWXXM 2025-2 XML format SWX string.
     */
    public static final ConversionSpecification<SpaceWeatherAdvisoryAmd82, String> SPACE_WEATHER_POJO_TO_IWXXM2025_2_STRING = new ConversionSpecification<>(
            SpaceWeatherAdvisoryAmd82.class, String.class, null, "SWX, XML/IWXXM 2025-2");

    /**
     * Pre-configured spec for {@link SpaceWeatherAdvisoryAmd82} to IWXXM 2025-2 XML format SWX document DOM node.
     */
    public static final ConversionSpecification<SpaceWeatherAdvisoryAmd82, Document> SPACE_WEATHER_POJO_TO_IWXXM2025_2_DOM = new ConversionSpecification<>(
            SpaceWeatherAdvisoryAmd82.class, Document.class, null, "SWX, XML/IWXXM 2025-2");

    /**
     * Pre-configured spec for {@link SpaceWeatherAmd82Bulletin} to WMO COLLECT 1.2 XML String containing IWXXM 3.0 SpaceWeatherAdvisories.
     */
    public static final ConversionSpecification<SpaceWeatherAmd82Bulletin, String> SWX_2025_2_BULLETIN_POJO_TO_WMO_COLLECT_STRING = new ConversionSpecification<>(
            SpaceWeatherAmd82Bulletin.class, String.class, null, "XML/WMO COLLECT 1.2 + IWXXM 2025-2 SWX");

    /**
     * Pre-configured spec for {@link SpaceWeatherAmd82Bulletin} to WMO COLLECT 1.2 XML DOM document containing IWXXM 3.0 SpaceWeatherAdvisories.
     */
    public static final ConversionSpecification<SpaceWeatherAmd82Bulletin, Document> SWX_2025_2_BULLETIN_POJO_TO_WMO_COLLECT_DOM = new ConversionSpecification<>(
            SpaceWeatherAmd82Bulletin.class, Document.class, null, "XML/WMO COLLECT 1.2 + IWXXM 2025-2 SWX");

    // *******************
    //  Generic aviation messages
    // *******************

    /**
     * Pre-configured spec for WMO COLLECT 1.2 XML DOM document to {@link GenericMeteorologicalBulletin}
     */
    public static final ConversionSpecification<Document, GenericMeteorologicalBulletin> WMO_COLLECT_DOM_TO_GENERIC_BULLETIN_POJO = new ConversionSpecification<>(
            Document.class, GenericMeteorologicalBulletin.class, "XML/WMO COLLECT 1.2", null);

    /**
     * Pre-configured spec for WMO COLLECT 1.2 XML document String to {@link GenericMeteorologicalBulletin}
     */
    public static final ConversionSpecification<String, GenericMeteorologicalBulletin> WMO_COLLECT_STRING_TO_GENERIC_BULLETIN_POJO = new ConversionSpecification<>(
            String.class, GenericMeteorologicalBulletin.class, "XML/WMO COLLECT 1.2", null);

    /**
     * Pre-configured spec for converting IWXXM string to {@link GenericAviationWeatherMessage}
     */
    public static final ConversionSpecification<String, GenericAviationWeatherMessage> IWXXM_STRING_TO_GENERIC_AVIATION_WEATHER_MESSAGE_POJO = new ConversionSpecification<>(
            String.class, GenericAviationWeatherMessage.class, "XML/IWXXM", null);

    /**
     * Pre-configured spec for converting IWXXM document to {@link GenericAviationWeatherMessage}
     */
    public static final ConversionSpecification<Document, GenericAviationWeatherMessage> IWXXM_DOM_TO_GENERIC_AVIATION_WEATHER_MESSAGE_POJO = new ConversionSpecification<>(
            Document.class, GenericAviationWeatherMessage.class, "XML/IWXXM", null);

}
