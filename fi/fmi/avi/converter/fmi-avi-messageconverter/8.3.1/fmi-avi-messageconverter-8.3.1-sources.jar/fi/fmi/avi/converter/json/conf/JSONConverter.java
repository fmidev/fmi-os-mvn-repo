package fi.fmi.avi.converter.json.conf;

import fi.fmi.avi.converter.AviMessageSpecificConverter;
import fi.fmi.avi.converter.ConversionSpecification;
import fi.fmi.avi.converter.json.*;
import fi.fmi.avi.model.bulletin.GenericMeteorologicalBulletin;
import fi.fmi.avi.model.metar.METAR;
import fi.fmi.avi.model.sigmet.AIRMET;
import fi.fmi.avi.model.sigmet.SIGMET;
import fi.fmi.avi.model.sigmet.SIGMETBulletin;
import fi.fmi.avi.model.swx.amd79.SpaceWeatherAdvisoryAmd79;
import fi.fmi.avi.model.swx.amd82.SpaceWeatherAdvisoryAmd82;
import fi.fmi.avi.model.taf.TAF;
import fi.fmi.avi.model.taf.TAFBulletin;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

/**
 * Spring configuration for Java POJO and JSON conversion.
 */
@SuppressWarnings("SpringFacetCodeInspection")
@Configuration
public class JSONConverter {

    /**
     * Pre-configured spec for {@link TAF} to fmi-avi-messageconverter JSON TAF document String.
     */
    public static final ConversionSpecification<TAF, String> TAF_POJO_TO_JSON_STRING = new ConversionSpecification<>(TAF.class, String.class,
            null, "TAF, fmi-avi-messageconverter JSON");

    /**
     * Pre-configured spec for {@link METAR} to fmi-avi-messageconverter JSON METAR document String.
     */
    public static final ConversionSpecification<METAR, String> METAR_POJO_TO_JSON_STRING = new ConversionSpecification<>(METAR.class, String.class,
            null, "METAR, fmi-avi-messageconverter JSON");

    /**
     * Pre-configured spec for {@link SIGMET} to fmi-avi-messageconverter JSON SIGMET document String.
     */
    public static final ConversionSpecification<SIGMET, String> SIGMET_POJO_TO_JSON_STRING = new ConversionSpecification<>(SIGMET.class, String.class,
            null, "SIGMET, fmi-avi-messageconverter JSON");

    /**
     * Pre-configured spec for {@link SpaceWeatherAdvisoryAmd79} to fmi-avi-messageconverter JSON SWX document String.
     */
    public static final ConversionSpecification<SpaceWeatherAdvisoryAmd79, String> SWX_AMD79_POJO_TO_JSON_STRING = new ConversionSpecification<>(SpaceWeatherAdvisoryAmd79.class, String.class,
            null, "SWX, fmi-avi-messageconverter JSON");

    /**
     * Pre-configured spec for {@link SpaceWeatherAdvisoryAmd82} to fmi-avi-messageconverter JSON SWX document String.
     */
    public static final ConversionSpecification<SpaceWeatherAdvisoryAmd82, String> SWX_AMD82_POJO_TO_JSON_STRING = new ConversionSpecification<>(SpaceWeatherAdvisoryAmd82.class, String.class,
            null, "SWX, fmi-avi-messageconverter JSON");

    /**
     * Pre-configured spec for {@link AIRMET} to IWXXM 2.1 XML format AIRMET document String.
     */
    public static final ConversionSpecification<AIRMET, String> AIRMET_POJO_TO_JSON_STRING = new ConversionSpecification<>(AIRMET.class, String.class,
            null, "SIGMET, fmi-avi-messageconverter JSON");

    /**
     * Pre-configured spec for {@link TAFBulletin} to fmi-avi-messageconverter JSON TAFBulletin document String.
     */
    public static final ConversionSpecification<TAFBulletin, String> TAF_BULLETIN_POJO_TO_JSON_STRING = new ConversionSpecification<>(TAFBulletin.class,
            String.class, null, "TAFBulletin, fmi-avi-messageconverter JSON");

    /**
     * Pre-configured spec for {@link SIGMETBulletin} to fmi-avi-messageconverter JSON SIGMETBulletin document String.
     */
    public static final ConversionSpecification<SIGMETBulletin, String> SIGMET_BULLETIN_POJO_TO_JSON_STRING = new ConversionSpecification<>(
            SIGMETBulletin.class, String.class, null, "SIGMETBulletin, fmi-avi-messageconverter JSON");


    /**
     * Pre-configured spec for {@link GenericMeteorologicalBulletin} to fmi-avi-messageconverter JSON GenericMeteorologicalBulletin document String.
     */
    public static final ConversionSpecification<GenericMeteorologicalBulletin, String> GENERIC_METEOROLOGICAL_BULLETIN_POJO_TO_JSON_STRING = new
            ConversionSpecification<>(
            GenericMeteorologicalBulletin.class, String.class, null, "GenericMeteorologicalBulletin, fmi-avi-messageconverter JSON");

    /**
     * Pre-configured spec for fmi-avi-messageconverter JSON TAF document String to {@link TAF}.
     */
    public static final ConversionSpecification<String, TAF> JSON_STRING_TO_TAF_POJO = new ConversionSpecification<>(String.class,TAF.class,
            "TAF, fmi-avi-messageconverter JSON", null);

    /**
     * Pre-configured spec for fmi-avi-messageconverter JSON SWX document String to {@link SpaceWeatherAdvisoryAmd79}.
     */
    public static final ConversionSpecification<String, SpaceWeatherAdvisoryAmd79> JSON_STRING_TO_SWX_AMD79_POJO = new ConversionSpecification<>(String.class, SpaceWeatherAdvisoryAmd79.class,
            "SWX, fmi-avi-messageconverter JSON", null);

    /**
     * Pre-configured spec for fmi-avi-messageconverter JSON SWX document String to {@link SpaceWeatherAdvisoryAmd82}.
     */
    public static final ConversionSpecification<String, SpaceWeatherAdvisoryAmd82> JSON_STRING_TO_SWX_AMD82_POJO = new ConversionSpecification<>(String.class, SpaceWeatherAdvisoryAmd82.class,
            "SWX, fmi-avi-messageconverter JSON", null);

    /**
     * Pre-configured spec for fmi-avi-messageconverter JSON METAR document String to {@link METAR}.
     */
    public static final ConversionSpecification<String, METAR> JSON_STRING_TO_METAR_POJO = new ConversionSpecification<>(String.class, METAR.class,
            "METAR, fmi-avi-messageconverter JSON", null);

    /**
     * Pre-configured spec for fmi-avi-messageconverter JSON SIGMET document String to {@link METAR}.
     */
    public static final ConversionSpecification<String, SIGMET> JSON_STRING_TO_SIGMET_POJO = new ConversionSpecification<>(String.class, SIGMET.class,
            "SIGMET, fmi-avi-messageconverter JSON", null);

    /**
     * Pre-configured spec for fmi-avi-messageconverter JSON TAFBulletin document String to {@link TAFBulletin}.
     */
    public static final ConversionSpecification<String, TAFBulletin> JSON_STRING_TO_TAF_BULLETIN_POJO = new ConversionSpecification<>(String.class,
            TAFBulletin.class, "TAFBulletin, fmi-avi-messageconverter JSON", null);

    /**
     * Pre-configured spec for fmi-avi-messageconverter JSON SIGMETBulletin document String to {@link SIGMETBulletin}.
     */
    public static final ConversionSpecification<String, SIGMETBulletin> JSON_STRING_TO_SIGMET_BULLETIN_POJO = new ConversionSpecification<>(String.class,
            SIGMETBulletin.class, "SIGMETBulletin, fmi-avi-messageconverter JSON", null);
    /**
     * Pre-configured spec for IWXXM 2.1 XML format AIRMET document DOM Node to {@link AIRMET}
     */
    public static final ConversionSpecification<String, AIRMET> JSON_STRING_TO_AIRMET_POJO = new ConversionSpecification<>(String.class, AIRMET.class,
            "AIRMET, fmi-avi-messageconverter JSON", null);


    /**
     * Pre-configured spec for fmi-avi-messageconverter JSON GenericMeteorologicalBulletin document String to
     * {@link GenericMeteorologicalBulletin}.
     */
    public static final ConversionSpecification<String, GenericMeteorologicalBulletin> JSON_STRING_TO_GENERIC_BULLETIN_POJO = new ConversionSpecification<>(String.class,
            GenericMeteorologicalBulletin.class, "GenericMeteorologicalBulletin, fmi-avi-messageconverter JSON", null);

    @Bean
    public AviMessageSpecificConverter<METAR, String> metarJSONSerializer() {
        return new METARJSONSerializer();
    }

    @Bean
    public AviMessageSpecificConverter<TAF, String> tafJSONSerializer() {
        return new TAFJSONSerializer();
    }

    @Bean
    public AviMessageSpecificConverter<SIGMET, String> sigmetJSONSerializer() {
        return new SIGMETJSONSerializer();
    }

    @Bean
    public AviMessageSpecificConverter<SpaceWeatherAdvisoryAmd79, String> swxAmd79JSONSerializer() {
        return new SpaceWeatherAdvisoryAmd79JSONSerializer();
    }

    @Bean
    public AviMessageSpecificConverter<SpaceWeatherAdvisoryAmd82, String> swxAmd82JSONSerializer() {
        return new SpaceWeatherAdvisoryAmd82JSONSerializer();
    }

    @Bean
    public AviMessageSpecificConverter<SIGMETBulletin, String> sigmetBulletinJSONSerializer() {
        return new SIGMETBulletinJSONSerializer();
    }

    @Bean
    public AviMessageSpecificConverter<GenericMeteorologicalBulletin, String> genericBulletinJSONSerializer() {
        return new GenericMeteorologicalBulletinJSONSerializer();
    }

    @Bean
    public AviMessageSpecificConverter<TAFBulletin, String> tafBulletinJSONSerializer() {
        return new TAFBulletinJSONSerializer();
    }

    @Bean
    public AviMessageSpecificConverter<String, TAF> tafJSONParser() {
        return new TAFJSONParser();
    }

    @Bean
    public AviMessageSpecificConverter<String, METAR> metarJSONParser() {
        return new METARJSONParser();
    }

    @Bean
    public AviMessageSpecificConverter<String, SIGMET> sigmetJSONParser() {
        return new SIGMETJSONParser();
    }

    @Bean
    public AviMessageSpecificConverter<String, SpaceWeatherAdvisoryAmd79> swxAmd79JSONParser() {
        return new SpaceWeatherAdvisoryAmd79JSONParser();
    }

    @Bean
    public AviMessageSpecificConverter<String, SpaceWeatherAdvisoryAmd82> swxAmd82JSONParser() {
        return new SpaceWeatherAdvisoryAmd82JSONParser();
    }

    @Bean
    public AviMessageSpecificConverter<String, AIRMET> airmetJSONParser() {return new AIRMETJSONParser();}

    @Bean
    public AviMessageSpecificConverter<String, TAFBulletin> tafBulletinJSONParser() {
        return new TAFBulletinJSONParser();
    }

    @Bean
    public AviMessageSpecificConverter<String, SIGMETBulletin> sigmetBulletinJSONParser() {
        return new SIGMETBulletinJSONParser();
    }

    @Bean
    public AviMessageSpecificConverter<String, GenericMeteorologicalBulletin> genericBulletinJSONParser() {
        return new GenericMeteorologicalBulletinJSONParser();
    }


    @Bean(name = "airmetJSONSerializer")
    public AviMessageSpecificConverter<AIRMET, String> airmetJSONSerializer() {
        return new AIRMETJSONSerializer();
    }

}
