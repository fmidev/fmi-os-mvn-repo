package fi.fmi.avi.archiver;

import javax.annotation.processing.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_ProcessingState_Status extends ProcessingState.Status {

  private final long start;

  private final int processingCount;

  AutoValue_ProcessingState_Status(
      long start,
      int processingCount) {
    this.start = start;
    this.processingCount = processingCount;
  }

  @Override
  public long getStart() {
    return start;
  }

  @Override
  public int getProcessingCount() {
    return processingCount;
  }

  @Override
  public String toString() {
    return "Status{"
        + "start=" + start + ", "
        + "processingCount=" + processingCount
        + "}";
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof ProcessingState.Status) {
      ProcessingState.Status that = (ProcessingState.Status) o;
      return this.start == that.getStart()
          && this.processingCount == that.getProcessingCount();
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= (int) ((start >>> 32) ^ start);
    h$ *= 1000003;
    h$ ^= processingCount;
    return h$;
  }

}
