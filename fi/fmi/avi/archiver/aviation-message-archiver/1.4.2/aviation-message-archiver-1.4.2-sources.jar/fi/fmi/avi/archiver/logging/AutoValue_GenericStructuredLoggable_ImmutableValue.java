package fi.fmi.avi.archiver.logging;

import com.fasterxml.jackson.annotation.JsonIgnore;
import javax.annotation.processing.Generated;
import org.jspecify.annotations.Nullable;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_GenericStructuredLoggable_ImmutableValue<T> extends GenericStructuredLoggable.ImmutableValue<T> {

  private final String structureName;

  private final @Nullable T value;

  private final String string;

  AutoValue_GenericStructuredLoggable_ImmutableValue(
      String structureName,
      @Nullable T value,
      String string) {
    if (structureName == null) {
      throw new NullPointerException("Null structureName");
    }
    this.structureName = structureName;
    this.value = value;
    if (string == null) {
      throw new NullPointerException("Null string");
    }
    this.string = string;
  }

  @JsonIgnore
  @Override
  public String getStructureName() {
    return structureName;
  }

  @Override
  public @Nullable T getValue() {
    return value;
  }

  @Override
  String getString() {
    return string;
  }

  @Override
  public boolean equals(@Nullable Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof GenericStructuredLoggable.ImmutableValue) {
      GenericStructuredLoggable.ImmutableValue<?> that = (GenericStructuredLoggable.ImmutableValue<?>) o;
      return this.structureName.equals(that.getStructureName())
          && (this.value == null ? that.getValue() == null : this.value.equals(that.getValue()))
          && this.string.equals(that.getString());
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= structureName.hashCode();
    h$ *= 1000003;
    h$ ^= (value == null) ? 0 : value.hashCode();
    h$ *= 1000003;
    h$ ^= string.hashCode();
    return h$;
  }

}
