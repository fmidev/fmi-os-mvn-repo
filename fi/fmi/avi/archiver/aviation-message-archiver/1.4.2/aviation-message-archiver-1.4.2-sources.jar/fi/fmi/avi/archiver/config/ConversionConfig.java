package fi.fmi.avi.archiver.config;

import fi.fmi.avi.archiver.spring.convert.*;
import org.springframework.boot.convert.ApplicationConversionService;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.convert.ConversionService;

@Configuration
public class ConversionConfig {

    @Bean
    ConversionService conversionService() {
        final ApplicationConversionService conversionService = new ApplicationConversionService();

        conversionService.addConverter(new EmptyStringToEmptyMapConverter());
        conversionService.addConverter(new MapValuesToCollectionConverter(conversionService));
        conversionService.addConverter(new NumberToOptionalDoubleConverter());
        conversionService.addConverter(new StringToPatternConverter());
        conversionService.addConverter(new StringToZonedDateTimeConverter());

        return conversionService;
    }

}
