package fi.fmi.avi.archiver.message;

import javax.annotation.processing.Generated;

@Generated("com.google.auto.value.processor.AutoValueProcessor")
final class AutoValue_MessagePositionInFile extends MessagePositionInFile {

  private final int bulletinIndex;

  private final int messageIndex;

  AutoValue_MessagePositionInFile(
      int bulletinIndex,
      int messageIndex) {
    this.bulletinIndex = bulletinIndex;
    this.messageIndex = messageIndex;
  }

  @Override
  public int getBulletinIndex() {
    return bulletinIndex;
  }

  @Override
  public int getMessageIndex() {
    return messageIndex;
  }

  @Override
  public boolean equals(Object o) {
    if (o == this) {
      return true;
    }
    if (o instanceof MessagePositionInFile) {
      MessagePositionInFile that = (MessagePositionInFile) o;
      return this.bulletinIndex == that.getBulletinIndex()
          && this.messageIndex == that.getMessageIndex();
    }
    return false;
  }

  @Override
  public int hashCode() {
    int h$ = 1;
    h$ *= 1000003;
    h$ ^= bulletinIndex;
    h$ *= 1000003;
    h$ ^= messageIndex;
    return h$;
  }

}
